import { useState } from 'react';

export default function CodeBlock({ examples, title }) {
  const [activeTab, setActiveTab] = useState('curl');
  
  const tabs = [
    { key: 'curl', label: 'cURL' },
    { key: 'javascript', label: 'JavaScript' },
    { key: 'python', label: 'Python' },
  ];

  const handleCopy = (text) => {
    // Only try to copy if we're in the browser
    if (typeof window !== 'undefined' && navigator?.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      });
    }
  };

  return (
    <div className="bg-gray-900 rounded-lg overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2 bg-gray-800">
        <div className="flex space-x-2">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-3 py-1 text-sm rounded ${
                activeTab === tab.key
                  ? 'bg-gray-700 text-white'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
        <button
          onClick={() => handleCopy(examples[activeTab] || '')}
          className="text-gray-400 hover:text-white text-sm"
        >
          Copy
        </button>
      </div>
      <div className="p-4">
        <pre className="text-sm text-gray-100 overflow-x-auto">
          <code>{examples[activeTab] || 'No example available'}</code>
        </pre>
      </div>
    </div>
  );
}