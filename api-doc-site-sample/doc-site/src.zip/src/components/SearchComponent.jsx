import { useState, useEffect } from 'react';
import Fuse from 'fuse.js';

export default function SearchComponent() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [fuse, setFuse] = useState(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // In a real implementation, you'd fetch this data from your content
    const searchData = [
      { title: 'Getting Started', url: '/guides/getting-started', type: 'guide' },
      { title: 'Authentication', url: '/guides/authentication', type: 'guide' },
      { title: 'Users API', url: '/api/users', type: 'api' },
      { title: 'Orders API', url: '/api/orders', type: 'api' },
    ];

    const fuseInstance = new Fuse(searchData, {
      keys: ['title', 'type'],
      threshold: 0.3,
    });

    setFuse(fuseInstance);
  }, []);

  useEffect(() => {
    if (fuse && query) {
      const searchResults = fuse.search(query);
      setResults(searchResults.slice(0, 5));
      setIsOpen(true);
    } else {
      setResults([]);
      setIsOpen(false);
    }
  }, [query, fuse]);

  return (
    <div className="relative">
      <input
        type="text"
        placeholder="Search documentation..."
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onFocus={() => query && setIsOpen(true)}
        onBlur={() => setTimeout(() => setIsOpen(false), 200)}
      />
      
      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50">
          {results.map((result, index) => (
            <a
              key={index}
              href={result.item.url}
              className="block px-4 py-2 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {result.item.title}
                </span>
                <span className={`text-xs px-2 py-1 rounded ${
                  result.item.type === 'guide' 
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                }`}>
                  {result.item.type}
                </span>
              </div>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}