import React, { useState } from 'react';

const OpenAPIEndpoint = ({ endpoint }) => {
  const [activeTab, setActiveTab] = useState('description');
  
  const methodColors = {
    GET: 'bg-green-100 text-green-800',
    POST: 'bg-blue-100 text-blue-800',
    PUT: 'bg-yellow-100 text-yellow-800',
    DELETE: 'bg-red-100 text-red-800',
    PATCH: 'bg-purple-100 text-purple-800',
  };

  const renderParameters = () => {
    if (!endpoint.parameters || endpoint.parameters.length === 0) {
      return <p className="text-gray-500">No parameters</p>;
    }

    return (
      <div className="space-y-4">
        {endpoint.parameters.map((param, index) => (
          <div key={index} className="border-b border-gray-100 pb-4">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded">
                  {param.name}
                </code>
                {param.required && (
                  <span className="ml-2 text-xs text-red-600 font-medium">required</span>
                )}
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-600 mb-1">
                  {param.schema?.type || param.type || 'string'} • {param.in}
                </div>
                <div className="text-sm text-gray-900">
                  {param.description || 'No description available'}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderResponses = () => {
    return (
      <div className="space-y-4">
        {Object.entries(endpoint.responses).map(([status, response]) => (
          <div key={status} className="border-b border-gray-100 pb-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
                {status}
              </span>
              <span className="text-sm text-gray-600">{response.description}</span>
            </div>
            {response.content && response.content['application/json'] && response.content['application/json'].example && (
              <div className="ml-4">
                <pre className="bg-gray-50 p-3 rounded text-sm overflow-x-auto">
                  <code>{JSON.stringify(response.content['application/json'].example, null, 2)}</code>
                </pre>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="my-8 rounded-lg border border-gray-200 bg-white overflow-hidden">
      <div className="border-b border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-3">
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${methodColors[endpoint.method] || 'bg-gray-100 text-gray-800'}`}>
            {endpoint.method}
          </span>
          <code className="text-lg font-mono">{endpoint.path}</code>
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{endpoint.summary}</h3>
        <p className="text-gray-600">{endpoint.description}</p>
      </div>

      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 px-6" aria-label="Tabs">
          {['description', 'parameters', 'responses'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 px-1 border-b-2 font-medium text-sm capitalize ${
                activeTab === tab
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'description' && (
          <div className="prose max-w-none">
            <p>{endpoint.description || 'No detailed description available.'}</p>
          </div>
        )}
        {activeTab === 'parameters' && renderParameters()}
        {activeTab === 'responses' && renderResponses()}
      </div>
    </div>
  );
};

export default OpenAPIEndpoint;