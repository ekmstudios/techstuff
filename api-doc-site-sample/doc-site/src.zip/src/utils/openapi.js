import SwaggerParser from 'swagger-parser';

export async function parseOpenAPISpec(specPath) {
  try {
    const api = await SwaggerParser.validate(specPath);
    return api;
  } catch (err) {
    console.error('Error parsing OpenAPI spec:', err);
    return null;
  }
}

export function extractEndpoints(spec) {
  const endpoints = [];
  
  for (const [path, methods] of Object.entries(spec.paths)) {
    for (const [method, details] of Object.entries(methods)) {
      if (['get', 'post', 'put', 'delete', 'patch'].includes(method.toLowerCase())) {
        endpoints.push({
          method: method.toUpperCase(),
          path,
          summary: details.summary || '',
          description: details.description || '',
          parameters: details.parameters || [],
          responses: details.responses || {},
          tags: details.tags || [],
        });
      }
    }
  }
  
  return endpoints;
}

export function groupEndpointsByTag(endpoints) {
  const grouped = {};
  
  endpoints.forEach(endpoint => {
    const tag = endpoint.tags[0] || 'Uncategorized';
    if (!grouped[tag]) {
      grouped[tag] = [];
    }
    grouped[tag].push(endpoint);
  });
  
  return grouped;
}