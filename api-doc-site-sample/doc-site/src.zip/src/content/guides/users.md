---
title: "Users"
description: "Learn how to authenticate with our API using API keys and OAuth"
category: "Users"
order: 1
publishDate: 2024-01-15
---

# Users

Our API supports two authentication methods: API Keys and OAuth 2.0.

## API Key Authentication

The simplest way to authenticate is using API keys.

### Getting Your API Key

1. Sign up for an account
2. Go to your dashboard
3. Generate a new API key

### Using Your API Key

Include your API key in the `Authorization` header:

```bash
curl -H "Authorization: Bearer sk_test_123..." \
  https://api.example.com/v1/users
```

## OAuth 2.0

For applications that need to act on behalf of users, use OAuth 2.0.

### Authorization Flow

1. Redirect users to our authorization endpoint
2. Users grant permission
3. Exchange authorization code for access token
4. Use access token to make API calls

```javascript
// Redirect to authorization endpoint
window.location.href = 'https://api.example.com/oauth/authorize?' +
  'client_id=your_client_id&' +
  'redirect_uri=https://yourapp.com/callback&' +
  'response_type=code&' +
  'scope=read_users';
```

## Best Practices

- Never expose API keys in client-side code
- Rotate keys regularly
- Use environment variables for secrets
- Implement proper error handling