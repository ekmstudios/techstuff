---
title: "Guides Home"
description: "Learn how to get started with our API"
category: "Guides"
order: 1
publishDate: 2025-06-19
---

# Maind Guides page

Welcome to our API! This guide will help you make your first API request in just a few minutes.

## Before you begin

You'll need:
- An API key (sign up to get one)
- A way to make HTTP requests (curl, Postman, or your favorite programming language)

## Authentication

All API requests require authentication using your API key. Include it in the `Authorization` header:

```bash
Authorization: Bearer YOUR_API_KEY
```

## Making your first request

Here's how to retrieve a list of users:

```bash
curl -X GET "https://api.example.com/v1/users" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json"
```

## Response format

All responses are returned in JSON format. Successful requests return a `2xx` status code.

```json
{
  "data": [
    {
      "id": "user_123",
      "email": "user@example.com",
      "created": 1234567890
    }
  ],
  "has_more": false
}
```

## Error handling

When something goes wrong, we'll return an appropriate HTTP status code along with details:

```json
{
  "error": {
    "type": "invalid_request_error",
    "message": "Missing required parameter: email"
  }
}
```

## Next steps

- Read our [Authentication guide](/guides/authentication) for more details
- Explore the [API Reference](/api) for all available endpoints
- Check out our [SDKs and libraries](/guides/sdks) for your programming language