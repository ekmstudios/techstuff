import { defineCollection, z } from 'astro:content';
/*
const guides = defineCollection({
  type: 'content',
  schema: z.object({
    title: z.string(),
    description: z.string(),
    category: z.string(),
    order: z.number().optional(),
    publishDate: z.date(),
    updatedDate: z.date().optional(),
  }),
});

const changelog = defineCollection({
  type: 'data',
  schema: z.object({
    version: z.string(),
    release_date: z.string(),
    changes: z.array(z.object({
      type: z.enum(['added', 'changed', 'deprecated', 'removed', 'fixed', 'security']),
      description: z.string(),
      endpoint: z.string().optional(),
      details: z.string().optional(),
    })),
  }),
});

const apiReference = defineCollection({
  type: 'data',
  schema: z.object({
    title: z.string(),
    description: z.string(),
    category: z.string(),
    order: z.number().optional(),
    endpoints: z.array(z.object({
      method: z.enum(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']),
      path: z.string(),
      summary: z.string(),
      description: z.string(),
      parameters: z.array(z.object({
        name: z.string(),
        type: z.string(),
        required: z.boolean(),
        description: z.string(),
        example: z.string().optional(),
      })).optional(),
      responses: z.array(z.object({
        status: z.number(),
        description: z.string(),
        example: z.string().optional(),
      })),
      examples: z.object({
        curl: z.string(),
        javascript: z.string().optional(),
        python: z.string().optional(),
      }),
    })),
  }),
});

export const collections = {
  guides,
  changelog,
  'api-reference': apiReference,
};
*/